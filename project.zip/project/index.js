// 1. Create a variable, listItems, to hold all the HTML for the list items
// Assign it to an empty string to begin with

// let listItems = ""
const inputBtn = document.getElementById("input-btn");
const inputEl = document.getElementById("input-el");
let myLeads = [];
const ulEl = document.getElementById("ul-el");

//on click Push the value from the inputEl into the myLeads array
// put list items and the for loop and innerHTMcontent in a function
// call that function inside the click function
inputBtn.addEventListener("click", () => {
  myLeads.push(inputEl.value);
  //clear input field
  inputEl.value = "";
  renderLeads();
});

// Add the item to the listItems variable instead of the ulEl.innerHTML
// Render the listItems inside the unordered list using ulEl.innerHTML
// Wrap the lead in an anchor tag (<a>) inside the <li> make the link open in a new tab?
const renderLeads = () => {
  let listItems = "";
  for (let i = 0; i < myLeads.length; i++) {
    listItems += `
   <li>
        <a href="${myLeads[i]}" target="_blank">
            ${myLeads[i]}
        </a>
    </li>`;
  }
  ulEl.innerHTML = listItems;
};

// Log out the items in the myLeads array using a for loop
// for (let i = 0; i < myLeads.length; i++) {
//     console.log(myLeads[i]);

// }

// Render the leads in the unordered list using ulEl.textContent
// here we use innerHTML because texContent renders everything written including tags, innerHTML will render it as a HTML element does
// for (let i = 0; i < myLeads.length; i++) {
//     ulEl.innerHTML += `<li> ${myLeads[i]} </>`
// }

// Let's try a different method for the same as above code
// for (let i = 0; i < myLeads.length; i++) {
//     const li = document.createElement("li")
//     li.textContent = myLeads[i]
//     ulEl.append(li);
// }
